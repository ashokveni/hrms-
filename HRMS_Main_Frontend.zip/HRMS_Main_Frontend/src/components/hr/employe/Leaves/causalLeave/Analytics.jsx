import React from "react";

function Analytics() {
  return <div>analytics</div>;
}

export default Analytics;
