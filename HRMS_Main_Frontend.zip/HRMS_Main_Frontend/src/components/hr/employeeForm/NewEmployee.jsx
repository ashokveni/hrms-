import React from 'react'
import SideBar from '../../Sidebar'
const NewEmployee = () => {
  return (
    <>
    
    <div>
        <SideBar />
    </div>
    <div>
       
    </div>
    </>
  )
}

export default NewEmployee